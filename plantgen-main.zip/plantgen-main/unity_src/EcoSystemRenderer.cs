using UnityEngine;
using System.IO;
using System.Linq;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using System;
using Unity.VisualScripting;
using System.Numerics;
using Vector3 = UnityEngine.Vector3;
using Quaternion = UnityEngine.Quaternion;
using Vector2 = UnityEngine.Vector2;
using UnityEngine.TerrainTools;
using Random = UnityEngine.Random;
using UnityEngine.Rendering;
public class EcosystemRenderer : MonoBehaviour {
   private string datasetBasepath = @"C:\Users\zwoom\Desktop\PlantGenCS\PlantGeneration\Assets";
   public string terrainFilePath = "";
   public string plantDataFilePath = "";  // Path to plant data file
   public GameObject treePrefab;          // Prefab for tree object
   public GameObject[] rockPrefabs;
   public GameObject
       emptySpotPrefab;  // Prefab for empty spots where no tree is placed
   public float heightScale = 1f;  // Scale factor
   public float terrainScale = 1f;

   private int terrainGenerationCount = 0;
   private int plantPlacementCount = 0;

   public float plantScale = 0.2441f;  // 122
   public Texture2D terrainTexture;

   public GameObject mountainPinePrefab;
   public GameObject snowyMespilusPrefab;
   public GameObject silverBirchPrefab;
   public GameObject europeanBeechPrefab;
   public GameObject boxwoodPrefab;
   public GameObject sessileOakPrefab;
   public GameObject silverFirPrefab;
   public EcosystemSimulationGUI guiController;
   private Vector3 initialCameraPosition;
   private Vector3 sideCameraPosition;
   private Vector3 terrainCenter;
   private float animationDuration = 5f;
   private bool animationComplete = false;

   public string selectedDataset;
   public bool isSimulationReady = false;

   public float baseExtension = 10f;

   public Material terrainMaterial;

   public GameObject loadingScreen;  // Assign this in the Inspector
   public GameObject guiObject;      // Assign this in the Inspector

   public Camera mainCamera;

   private int simulationStartCount = 0;

   private Mesh sideMesh;
   // Dictionary
   private Dictionary<string, float> speciesScaleFactors =
       new Dictionary<string, float> { { "Silver fir", 0.1f } };
   private Dictionary<string, Color> speciesColors =
       new Dictionary<string, Color> {

          { "Mountain Pine", Color.black },   // Saddle Brown
          { "Snowy Mespilus", Color.red },    // Peru
          { "Silver Birch", Color.magenta },  // Brown
          { "European Beech", Color.green },  // Burlywood
          { "Boxwood", Color.yellow },        // Dark Goldenrod
          { "Sessile Oak", Color.cyan },      // Dark Brown
          { "Silver Fir", Color.blue },       // Sienna
          { "None", Color.gray },             // Tan
       };
   IEnumerator Start() {
      string path = Path.Combine(Application.streamingAssetsPath,
                                 "aerial_grass_rock_diff_4k.png");
      Debug.Log("reading texture" + path);
      byte[] fileData = File.ReadAllBytes(path);
      terrainTexture = new Texture2D(2, 2);
      terrainTexture.LoadImage(fileData);

      {
         AssetBundle myLoadedAssetBundle = AssetBundle.LoadFromFile(
             Path.Combine(Application.streamingAssetsPath, "terrainassets"));
         if (myLoadedAssetBundle == null) {
            Debug.Log("Failed to load AssetBundle!");
            yield break;
         }

         var assetLoadRequest = myLoadedAssetBundle.LoadAssetAsync<Texture2D>(
             "aerial_grass_rock_diff_4k.png");
         yield return assetLoadRequest;

         terrainTexture = assetLoadRequest.asset as Texture2D;
         myLoadedAssetBundle.Unload(false);
      }

      if (mainCamera == null) {
         mainCamera = Camera.main;
      }
      PositionCameraOnGUI();
   }

   void PositionCameraOnGUI() {
      if (guiObject != null && mainCamera != null) {
         RectTransform guiRect = guiObject.GetComponent<RectTransform>();
         if (guiRect != null) {
            Vector3 centerPosition =
                guiRect.TransformPoint(guiRect.rect.center);
            mainCamera.transform.position =
                centerPosition - mainCamera.transform.forward * 10;
            mainCamera.transform.LookAt(centerPosition);
         }
      }
   }

   void Awake() {
      // Set the base path to the Assets folder
      datasetBasepath = Application.dataPath;
   }

   // Function to load terrain data
   IEnumerator LoadTerrainAndRenderEcosystemCoroutine() {
      try {
         terrainGenerationCount++;
         Debug.Log(
             $"Starting terrain generation. Count: {terrainGenerationCount}");

         // Load Terrain
         string[] terrainLines = File.ReadAllLines(
             terrainFilePath);  // Reads all lines from the terrain data file
         string[] metadata = terrainLines[0].Split(
             new char[] { ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
         int terrainWidth = int.Parse(metadata[0]);
         int terrainLength = int.Parse(metadata[1]);
         float gridSpacing =
             float.Parse(metadata[2], CultureInfo.InvariantCulture);
         Debug.Log("TerrainWidth:" + terrainWidth +
                   "TerrainHeight: " + terrainLength);
         float terrainScale =
             float.Parse(metadata[2], CultureInfo.InvariantCulture);

         Debug.Log(
             $"Terrain Dimensions: {terrainWidth}x{terrainLength}, Grid Spacing: {gridSpacing}m");

         // Initializizing the heights array
         float[,] heights = new float[terrainWidth, terrainLength];
         float[] rawHeights =
             terrainLines.Skip(1)
                 .SelectMany(line => line.Split(
                                 new char[] { ' ' },
                                 System.StringSplitOptions.RemoveEmptyEntries))
                 .Select(
                     s => float.Parse(
                         s,
                         CultureInfo.InvariantCulture))  // Parses height values
                                                         // from each line
                 .ToArray();

         // Finding the min and max height values
         float minHeight = rawHeights.Min();
         float maxHeight = rawHeights.Max();
         float heightRange = maxHeight - minHeight;

         // Normalize heights and initialize the height array
         for (int y = 0; y < terrainLength; y++) {
            for (int x = 0; x < terrainWidth; x++) {
               heights[x, y] = (rawHeights[y * terrainWidth + x] - minHeight) /
                               heightRange;  // 0-1
            }
         }

         TerrainData terrainData = new TerrainData();
         terrainData.heightmapResolution = terrainWidth + 1;
         terrainData.size =
             new Vector3(terrainWidth * gridSpacing, heightRange * heightScale,
                         terrainLength * gridSpacing);
         terrainData.SetHeights(0, 0, heights);

         if (terrainTexture != null) {
            terrainData.terrainLayers = new TerrainLayer[] { new TerrainLayer {
               diffuseTexture = terrainTexture,
               tileSize = new Vector2(terrainData.size.x, terrainData.size.z)
            } };
         } else {
            Debug.LogWarning("Terrain texture is not assigned!");
         }

         // Creates the terrain GameObject
         GameObject terrainObject =
             Terrain.CreateTerrainGameObject(terrainData);
         terrainObject.transform.position =
             new Vector3(0, minHeight - baseExtension, 0);

         Terrain terrain = terrainObject.GetComponent<Terrain>();
         UpdateTerrainMaterial(terrain);
         CreateSideMesh(terrainObject, terrainData);

         Debug.Log(
             $"Terrain created at position {terrainObject.transform.position} with size {terrainData.size}");
         Debug.Log($"Terrain loaded successfully! Size: {terrainData.size}");
         Vector3 terrainPosition = terrainObject.transform.position;

         // Render Plants
         string[] plantLines = File.ReadAllLines(plantDataFilePath);
         int numPoints = int.Parse(plantLines[0].Split(' ')[3]);
         Debug.Log(
             $"Reading plant data from {plantDataFilePath}. Total points: {numPoints}");

         // Skip the header line
         // Inside the plant placement loop
         for (int i = 2; i < plantLines.Length; i++) {
            string[] data = plantLines[i].Split(
                new char[] { ' ' },
                System.StringSplitOptions.RemoveEmptyEntries);
            if (data.Length < 8) {
               Debug.LogWarning(
                   $"Line {i} skipped due to insufficient data: {string.Join(", ", data)}");
               continue;
            }

            Debug.Log($"Processing line {i}: {string.Join(", ", data)}");

            float x, z, elevation, plantHeight, canopyRadius;
            if (!TryParseFloat(data[0], out x) ||
                !TryParseFloat(data[1], out z) ||
                !TryParseFloat(data[2], out elevation) ||
                !TryParseFloat(data[5], out plantHeight) ||
                !TryParseFloat(data[6], out canopyRadius)) {
               Debug.LogError(
                   $"Failed to parse values at line {i}: {string.Join(", ", data)}");
               continue;
            }

            string species = string.Join(" ", data.Skip(7));
            Debug.Log(
                $"Parsed data - X: {x}, Z: {z}, Elevation: {elevation}, Plant Height: {plantHeight}, Canopy Radius: {canopyRadius}, Species: {species}");

            int gridX = Mathf.Clamp(Mathf.FloorToInt(x / gridSpacing), 0,
                                    terrainWidth - 1);
            int gridZ = Mathf.Clamp(Mathf.FloorToInt(z / gridSpacing), 0,
                                    terrainLength - 1);

            Vector3 worldPosition = new Vector3(x, 0, z);
            float terrainHeight = terrain.SampleHeight(worldPosition);
            worldPosition.y = terrainHeight + terrainPosition.y;

            GameObject plantPrefab = GetPrefabForSpecies(species);

            GameObject plantObject;

            if (species == "None") {
               if (UnityEngine.Random.value <
                   0.4f)  // 20% chance to place a rock instead of an empty spot
               {
                  int randomRockIndex = Random.Range(0, rockPrefabs.Length);
                  plantObject = Instantiate(rockPrefabs[randomRockIndex],
                                            worldPosition, Quaternion.identity);
                  plantObject.transform.localScale =
                      Vector3.one *
                      Random.Range(0.5f, 5f * plantScale /
                                             3);  // Random size for variety
                  plantObject.transform.rotation = Quaternion.Euler(
                      0, Random.Range(0f, 360f), 0);  // Random rotation
               } else {
                  plantObject = Instantiate(emptySpotPrefab, worldPosition,
                                            Quaternion.identity);
                  plantObject.transform.localScale = Vector3.one * 0.5f;
               }
            }

            if (species != "None") {
               // Use the specific prefab based on the species
               GameObject selectedPrefab = GetPrefabForSpecies(species);
               plantObject = Instantiate(selectedPrefab, worldPosition,
                                         Quaternion.identity);
               float speciesScaleFactor = 1f;

               if (speciesScaleFactors.TryGetValue(species, out float factor)) {
                  speciesScaleFactor = factor;
               }
               float scaleFactor = (gridSpacing / terrainScale) * plantScale;

               if (species == "Silver fir" || species == "Silver Fir") {
                  scaleFactor *= 0.5F;
                  Debug.Log(
                      $"Applied Silver fir scale factor. New scale: {scaleFactor}");
               }

               plantObject.transform.localScale = new Vector3(
                   canopyRadius * 2 * scaleFactor, plantHeight * scaleFactor,
                   canopyRadius * scaleFactor * 2);

               if (treePrefab != null) {
                  Renderer renderer = plantObject.GetComponent<Renderer>();
                  if (renderer != null &&
                      speciesColors.TryGetValue(species, out Color color)) {
                     renderer.material.color = color;
                  }
               }
            } else {
               plantObject = Instantiate(emptySpotPrefab, worldPosition,
                                         Quaternion.identity);
               plantObject.transform.localScale = Vector3.one * 0.5f;
            }

            plantObject.name = $"Plant_{i-1}_{species}";
            Debug.Log(
                $"Placed {species} at position {worldPosition}, Scale: {plantObject.transform.localScale}, Terrain height: {terrainHeight}");
         }

         PositionCamera(terrainObject);
         Debug.Log($"Rendered {numPoints} plants successfully!");

      } catch (System.Exception e) {
         Debug.LogError(
             $"Error loading terrain and rendering ecosystem: {e.Message}\n{e.StackTrace}");
         if (loadingScreen != null) {
            loadingScreen.SetActive(false);
         } else {
            Debug.LogWarning("Loading screen object not assigned");
         }

         if (guiObject != null) {
            guiObject.SetActive(false);
         } else {
            Debug.LogWarning("GUI object not assigned");
         }
         StartCoroutine(AnimateCamera());
      }
      yield return null;
   }

   void CreateSideMesh(GameObject terrainObject, TerrainData terrainData) {
      Mesh sideMesh = new Mesh();
      List<Vector3> vertices = new List<Vector3>();
      List<int> triangles = new List<int>();
      List<Vector2> uvs = new List<Vector2>();

      int width = terrainData.heightmapResolution;
      int length = terrainData.heightmapResolution;
      Vector3 size = terrainData.size;

      for (int side = 0; side < 4; side++) {
         bool isWidthSide = (side % 2 == 0);
         int sideLength = isWidthSide ? width : length;

         for (int i = 0; i < sideLength; i++) {
            float x = isWidthSide ? i / (float)(width - 1) * size.x
                                  : (side == 1 ? size.x : 0);
            float z = isWidthSide ? (side == 0 ? 0 : size.z)
                                  : i / (float)(length - 1) * size.z;
            float y = terrainData.GetHeight(
                isWidthSide ? i : (side == 1 ? width - 1 : 0),
                isWidthSide ? (side == 0 ? 0 : length - 1) : i);

            vertices.Add(new Vector3(x, y, z));
            vertices.Add(new Vector3(x, -baseExtension, z));

            float uvX =
                isWidthSide ? i / (float)(sideLength - 1) : (side == 1 ? 1 : 0);
            float uvY =
                isWidthSide ? (side == 0 ? 0 : 1) : i / (float)(sideLength - 1);
            uvs.Add(new Vector2(uvX, 1));
            uvs.Add(new Vector2(uvX, 0));
         }
      }

      for (int side = 0; side < 4; side++) {
         int startIndex = side * width * 2;
         for (int i = 0; i < width * 2 - 2; i += 2) {
            triangles.AddRange(
                new int[] { startIndex + i, startIndex + i + 2,
                            startIndex + i + 1, startIndex + i + 1,
                            startIndex + i + 2, startIndex + i + 3 });
         }
      }

      sideMesh.vertices = vertices.ToArray();
      sideMesh.triangles = triangles.ToArray();
      sideMesh.uv = uvs.ToArray();
      sideMesh.RecalculateNormals();
      GameObject sideObject = new GameObject("TerrainSides");
      sideObject.transform.SetParent(terrainObject.transform);
      sideObject.transform.localPosition = Vector3.zero;

      MeshFilter meshFilter = sideObject.AddComponent<MeshFilter>();
      meshFilter.mesh = sideMesh;

      MeshRenderer meshRenderer = sideObject.AddComponent<MeshRenderer>();

      // Use the terrain material for the side mesh
      if (terrainMaterial != null) {
         meshRenderer.material = terrainMaterial;
      } else {
         // Fallback to a standard material with the terrain texture
         meshRenderer.material =
             new Material(Shader.Find("Nature/Terrain/Diffuse"));
         if (terrainTexture != null) {
            meshRenderer.material.mainTexture = terrainTexture;
         } else {
            Debug.LogWarning(
                "No terrain texture assigned. Side mesh may appear pink.");
         }
      }
   }
   private bool TryParseFloat(string value, out float result) {
      // Replace comma with period for proper parsing
      value = value.Replace(',', '.');
      Debug.Log($"Attempting to parse value: '{value}'");

      if (float.TryParse(value, NumberStyles.Float,
                         CultureInfo.InvariantCulture, out result)) {
         Debug.Log($"Successfully parsed value: {result}");
         return true;
      }

      Debug.LogWarning($"Failed to parse float value: '{value}'");
      result = 0;
      return false;
   }

   void PositionCamera(GameObject terrainObject) {
      Terrain terrain = terrainObject.GetComponent<Terrain>();
      if (terrain != null) {
         Vector3 terrainSize = terrain.terrainData.size;
         terrainCenter = terrain.transform.position + terrainSize * 0.5f;

         float cameraDistance = Mathf.Max(terrainSize.x, terrainSize.z) * 1f;

         // Set initial camera position (top view)
         initialCameraPosition =
             terrainCenter + Vector3.up * (terrainSize.y + cameraDistance);

         // Set side camera position
         sideCameraPosition =
             terrainCenter +
             new Vector3(cameraDistance, terrainSize.y * 2f, -cameraDistance);

         // Don't move the camera yet, just store the positions

         // Adjust the camera's far clip plane to ensure it can see the entire
         // terrain
         Camera.main.farClipPlane = cameraDistance * 3;

         Debug.Log(
             $"Camera positions calculated. Initial: {initialCameraPosition}, Side: {sideCameraPosition}");
      } else {
         Debug.LogError("Terrain component not found on the terrain object.");
      }
   }

   private GameObject GetPrefabForSpecies(string species) {
      // Check if treePrefab is set (not 'None')
      if (treePrefab != null) {
         // If treePrefab is set, always return treePrefab, regardless of
         // species
         return treePrefab;
      }

      // If treePrefab is set to None (null), use species-specific prefabs
      GameObject selectedPrefab =
          emptySpotPrefab;  // Default in case of unknown species or "None"

      switch (species) {
         case "Mountain Pine":
            selectedPrefab = mountainPinePrefab;
            break;
         case "Snowy Mespilus":
            selectedPrefab = snowyMespilusPrefab;
            break;
         case "Silver Birch":
            selectedPrefab = silverBirchPrefab;
            break;
         case "European Beech":
            selectedPrefab = europeanBeechPrefab;
            break;
         case "Boxwood":
            selectedPrefab = boxwoodPrefab;
            break;
         case "Sessile Oak":
            selectedPrefab = sessileOakPrefab;
            break;
         case "Silver Fir":
            selectedPrefab = silverFirPrefab;
            break;
         case "None":
            selectedPrefab = emptySpotPrefab;  // No plant, empty spot prefab
            break;
         default:
            Debug.LogWarning(
                $"Unknown species: {species}. Using default empty spot prefab.");
            break;
      }

      return selectedPrefab;
   }

   public void UpdateTerrainMaterial(Terrain terrain) {
      if (terrainTexture != null && terrain != null) {
         // Create a new material with the URP Lit shader
         Material terrainMaterial =
             new Material(Shader.Find("Universal Render Pipeline/Lit"));

         // Set up the terrain layers
         TerrainLayer terrainLayer = new TerrainLayer();
         terrainLayer.diffuseTexture = terrainTexture;
         terrainLayer.tileSize = new Vector2(terrain.terrainData.size.x,
                                             terrain.terrainData.size.z);

         // Assign the layer to the terrain
         terrain.terrainData.terrainLayers =
             new TerrainLayer[] { terrainLayer };

         // Set the main texture of the material
         terrainMaterial.SetTexture("_BaseMap", terrainTexture);

         // Assign the material to the terrain
         terrain.materialTemplate = terrainMaterial;

         Debug.Log("Terrain material updated for URP.");
      } else {
         Debug.LogError(
             "Failed to update terrain material: Texture or Terrain is null.");
      }
   }

   public void SetSelectedDataset(string dataset) {
      selectedDataset = dataset;
      UpdateDataPaths();
      CheckSimulationReadiness();
   }
   private void CheckSimulationReadiness() {
      isSimulationReady = !string.IsNullOrEmpty(terrainFilePath) &&
                          !string.IsNullOrEmpty(plantDataFilePath) &&
                          File.Exists(terrainFilePath) &&
                          File.Exists(plantDataFilePath);

      if (isSimulationReady) {
         Debug.Log("Simulation is ready to start.");
      } else {
         Debug.LogWarning(
             "Simulation is not ready. Please check the terrain and plant data files.");
      }
   }

   private void UpdateDataPaths() {
      // Construct the full path to the dataset folder
      string datasetPath = Path.Combine(datasetBasepath, selectedDataset);

      Debug.Log("dataset " + datasetBasepath);
      // Find the correct terrain file
      string[] terrainFiles =
          Directory.GetFiles(datasetPath, $"{selectedDataset}-*.elv");
      if (terrainFiles.Length > 0) {
         terrainFilePath = terrainFiles[0];
         Debug.Log(terrainFilePath);
      } else {
         Debug.LogError($"No terrain file found for dataset {selectedDataset}");
         return;
      }

      // Extract the resolution from the terrain file name
      string resolution =
          Path.GetFileNameWithoutExtension(terrainFilePath).Split('-')[1];
      Debug.Log(resolution + "resolution");

      // Set the plant data file path
      plantDataFilePath = Path.Combine(
          datasetPath, $"{selectedDataset}-{resolution}_points.txt");

      // Log the paths for debugging
      Debug.Log($"Updated terrain file path: {terrainFilePath}");
      Debug.Log($"Updated plant data file path: {plantDataFilePath}");

      // Check if the files exist
      if (!File.Exists(terrainFilePath)) {
         Debug.LogError($"Terrain file not found at path: {terrainFilePath}");
      }
      if (!File.Exists(plantDataFilePath)) {
         Debug.LogError(
             $"Plant data file not found at path: {plantDataFilePath}");
      }
   }

   public void StartSimulation() {
      if (isSimulationReady) {
         StartCoroutine(SimulationSequence());
      } else {
         Debug.LogWarning(
             "Simulation is not ready. Please ensure all parameters are set.");
         if (loadingScreen != null) {
            loadingScreen.SetActive(false);
         }
         if (guiObject != null) {
            guiObject.SetActive(true);
         }
      }
   }

   IEnumerator SimulationSequence() {
      Debug.Log("Starting Simulation Sequence");
      yield return StartCoroutine(LoadTerrainAndRenderEcosystemCoroutine());
      if (loadingScreen != null) {
         loadingScreen.SetActive(true);
      }
      if (guiObject != null) {
      }

      // Load terrain and ecosystem
      Debug.Log("Ecosystem loading complete");

      // Hide loading screen
      if (guiController != null) {
         guiController.HideLoadingScreen();
      } else {
         Debug.LogWarning(
             "GUI Controller not assigned, cannot update GUI state");
      }

      // Start camera animation
      yield return StartCoroutine(AnimateCamera());

      // Enable free camera movement
      EnableFreeCameraMovement();
   }

   public IEnumerator AnimateCamera() {
      if (Camera.main == null) {
         Debug.LogError("Main camera not found!");
         yield break;
      }

      Vector3 startPosition = Camera.main.transform.position;
      Quaternion startRotation = Camera.main.transform.rotation;

      float elapsedTime = 0f;

      while (elapsedTime < animationDuration) {
         elapsedTime += Time.deltaTime;
         float t = elapsedTime / animationDuration;

         // First half of animation: move from top to side
         if (t <= 0.5f) {
            float adjustedT = t * 2f;
            Camera.main.transform.position =
                Vector3.Lerp(startPosition, sideCameraPosition, adjustedT);
         }
         // Second half of animation: rotate around the terrain
         else {
            float adjustedT = (t - 0.5f) * 2f;
            float angle = adjustedT * -90f;
            Vector3 rotatedPosition = RotatePointAroundPivot(
                sideCameraPosition, terrainCenter, Vector3.up, angle);
            Camera.main.transform.position = rotatedPosition;
         }

         Camera.main.transform.LookAt(terrainCenter);

         yield return null;
      }

      animationComplete = true;
      EnableFreeCameraMovement();
   }
   Vector3 RotatePointAroundPivot(Vector3 point, Vector3 pivot, Vector3 axis,
                                  float angle) {
      return pivot + Quaternion.AngleAxis(angle, axis) * (point - pivot);
   }

   void EnableFreeCameraMovement() {
      if (mainCamera != null) {
         FreeCameraController freeCamera =
             mainCamera.gameObject.GetComponent<FreeCameraController>();
         if (freeCamera == null) {
            freeCamera =
                mainCamera.gameObject.AddComponent<FreeCameraController>();
         }
         freeCamera.enabled = true;
      }
   }
}

public class FreeCameraController : MonoBehaviour {
   public float moveSpeed = 250f;
   public float mouseSensitivity = 2f;
   private float rotationX = 0f;
   private float rotationY = 0f;

   void Update() {
      // Rotation
      if (Input.GetMouseButton(1))  // Right mouse button
      {
         rotationX += Input.GetAxis("Mouse X") * mouseSensitivity;
         rotationY -= Input.GetAxis("Mouse Y") * mouseSensitivity;
         rotationY = Mathf.Clamp(rotationY, -90f, 90f);
         transform.rotation = Quaternion.Euler(rotationY, rotationX, 0f);
      }

      // Movement
      float moveHorizontal = Input.GetAxis("Horizontal");
      float moveVertical = Input.GetAxis("Vertical");
      float moveUp =
          Input.GetKey(KeyCode.E) ? 1f : (Input.GetKey(KeyCode.Q) ? -1f : 0f);

      Vector3 movement = transform.right * moveHorizontal +
                         transform.forward * moveVertical +
                         transform.up * moveUp;
      transform.position += movement * moveSpeed * Time.deltaTime;
   }
}
