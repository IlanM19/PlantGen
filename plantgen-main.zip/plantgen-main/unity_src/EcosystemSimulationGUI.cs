using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class EcosystemSimulationGUI : MonoBehaviour {
   public EcosystemRenderer ecosystemRenderer;
   public Dropdown GridSelector;
   public Button startSimulationButton;

   public Canvas GUI;
   public GameObject loadingScreen;

   private bool isSimulationRunning = false;
   private int simulationStartCount = 0;

   void Start() {
      if (ecosystemRenderer == null || GridSelector == null ||
          startSimulationButton == null) {
         Debug.LogError(
             "Required components are not assigned in the Inspector");
         return;
      }

      PopulateDatasetDropdown();
      GridSelector.onValueChanged.AddListener(OnDatasetSelected);
      startSimulationButton.onClick.RemoveAllListeners();
      startSimulationButton.onClick.AddListener(OnStartSimulationClicked);
      loadingScreen.SetActive(false);
   }

   void PositionCameraOnButton() {
      Camera.main.transform.position =
          startSimulationButton.transform.position + new Vector3(0, 0, -10);
      Camera.main.transform.LookAt(startSimulationButton.transform);
   }

   void PopulateDatasetDropdown() {
      Debug.Log("Populating dataset dropdown");
      GridSelector.options.Clear();

      string[] datasetDirectories =
          Directory.GetDirectories(Application.dataPath, "D*");
      foreach (string directory in datasetDirectories) {
         string datasetName = Path.GetFileName(directory);
         GridSelector.options.Add(new Dropdown.OptionData(datasetName));
      }

      if (GridSelector.options.Count > 0) {
         GridSelector.value = 0;
         GridSelector.RefreshShownValue();
         OnDatasetSelected(0);
      }

      Debug.Log(
          $"Dataset dropdown populated with {GridSelector.options.Count} options");
   }

   void OnDatasetSelected(int index) {
      string selectedDataset = GridSelector.options[index].text;
      ecosystemRenderer.SetSelectedDataset(selectedDataset);
      Debug.Log($"Selected dataset: {selectedDataset}");

      // Update the start simulation button state
      startSimulationButton.interactable = ecosystemRenderer.isSimulationReady;
   }

   void OnStartSimulationClicked() {
      Debug.Log("Start Simulation button clicked");

      if (isSimulationRunning) {
         Debug.LogWarning("Simulation is already running. Ignoring click.");
         return;
      }

      isSimulationRunning = true;
      loadingScreen.SetActive(true);

      // Use Invoke to give the UI a chance to update before starting the heavy
      // computation
      Invoke("StartSimulationDelayed", 0.1f);
   }

   void StartSimulationDelayed() {
      if (ecosystemRenderer != null) {
         ecosystemRenderer.StartSimulation();
         Debug.Log("Simulation started");
      } else {
         Debug.LogError("EcosystemRenderer not assigned");
         ResetSimulationState();
      }
   }

   public void OnSimulationComplete() {
      loadingScreen.SetActive(true);
      GUI.gameObject.SetActive(false);
      Debug.Log("Simulation completed, GUI updated.");
      ResetSimulationState();
   }

   public void HideLoadingScreen() {
      loadingScreen.SetActive(false);
      GUI.gameObject.SetActive(false);
      Debug.Log("Loading screen hidden, GUI deactivated.");
   }

   private void ResetSimulationState() {
      isSimulationRunning = false;
      loadingScreen.SetActive(true);
      GUI.gameObject.SetActive(false);
   }
}
