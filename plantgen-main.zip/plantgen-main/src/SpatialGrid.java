import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class SpatialGrid {
   private final int cols;
   private final int rows;
   private final double cellSize;
   private double actualWidth;
   private double actualHeight;
   private final Double[][] elevationGrid;
   private final double[][] slopeGrid;
   private final Double[][][] sunGrid;
   private final Double[][][] moistGrid;
   private final Double[][][] tempGrid;
    private List < Point > allPoints;

   public SpatialGrid(int cols, int rows, double cellSize, Double[][] elevationGrid, AbioticData sun_data, AbioticData wet_data, AbioticData temp_data, double actualWidth, double actualHeight) {
      this.cols = cols;
      this.rows = rows;
      this.cellSize = cellSize;
      this.elevationGrid = elevationGrid;
      this.slopeGrid = new double[rows][cols];
      this.sunGrid = sun_data.getMonthlyData();
      this.moistGrid = wet_data.getMonthlyData();
      this.tempGrid = temp_data.getMonthlyData();
      this.actualWidth = actualWidth;
      this.actualHeight = actualHeight;

      calculateSlopes();
   }

   private void calculateSlopes() {
      for (int y = 0; y < rows; y++) {
         for (int x = 0; x < cols; x++) {
            slopeGrid[y][x] = calculateSlopeAtPoint(x, y);
         }
      }
   }

   private double calculateSlopeAtPoint(int x, int y) {


      double dzdx, dzdy;

      if (x == 0) {
         dzdx = (elevationGrid[y][x + 1] - elevationGrid[y][x]) / cellSize;
      } else if (x == cols - 1) {
         dzdx = (elevationGrid[y][x] - elevationGrid[y][x - 1]) / cellSize;
      } else {
         dzdx = (elevationGrid[y][x + 1] - elevationGrid[y][x - 1]) / (2 * cellSize);
      }

      if (y == 0) {
         dzdy = (elevationGrid[y + 1][x] - elevationGrid[y][x]) / cellSize;
      } else if (y == rows - 1) {
         dzdy = (elevationGrid[y][x] - elevationGrid[y - 1][x]) / cellSize;
      } else {
         dzdy = (elevationGrid[y + 1][x] - elevationGrid[y - 1][x]) / (2 * cellSize);
      }


      double slopeRadians = Math.atan(Math.sqrt(dzdx * dzdx + dzdy * dzdy));


      return Math.toDegrees(slopeRadians);
   }


   private double clamp(double value, double max) {
      return Math.max(0, Math.min(max, value));
   }

   public double interpolateSlope(double x, double y) {

      x = clamp(x, cols - 1.00001);
      y = clamp(y, rows - 1.00001);

      int x0 = (int) Math.floor(x);
      int x1 = Math.min(x0 + 1, cols - 1);
      int y0 = (int) Math.floor(y);
      int y1 = Math.min(y0 + 1, rows - 1);

      double wx = x - x0;
      double wy = y - y0;

      double v00 = slopeGrid[y0][x0];
      double v10 = slopeGrid[y0][x1];
      double v01 = slopeGrid[y1][x0];
      double v11 = slopeGrid[y1][x1];

      // Bilinear interpolation
      return v00 * (1 - wx) * (1 - wy) +
         v10 * wx * (1 - wy) +
         v01 * (1 - wx) * wy +
         v11 * wx * wy;
   }

   public double interpolateElevation(double x, double y) {

      return interpolateValue(x, y, elevationGrid);
   }

   public double interpolateSunlight(double x, double y, int month) {

      return interpolateValue(x, y, sunGrid[month]);
   }

   public double interpolateTemperature(double x, double y, int month) {

      return interpolateValue(x, y, tempGrid[month]);
   }

   public double interpolateMoisture(double x, double y, int month) {

      return interpolateValue(x, y, moistGrid[month]);
   }

   private double interpolateValue(double x, double y, Double[][] grid) {
      x = clamp(x, (cols - 1) * cellSize);
      y = clamp(y, (rows - 1) * cellSize);

      double gridX = x / cellSize;
      double gridY = y / cellSize;

      int x0 = (int) Math.floor(gridX);
      int x1 = Math.min(x0 + 1, cols - 1);
      int y0 = (int) Math.floor(gridY);
      int y1 = Math.min(y0 + 1, rows - 1);

      double wx = (x / cellSize) - x0;
      double wy = (y / cellSize) - y0;

      double v00 = grid[y0][x0];
      double v10 = grid[y0][x1];
      double v01 = grid[y1][x0];
      double v11 = grid[y1][x1];

      return v00 * (1 - wx) * (1 - wy) +
         v10 * wx * (1 - wy) +
         v01 * (1 - wx) * wy +
         v11 * wx * wy;
   }

   public void exportSlopeData(String filename) throws IOException {
      try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {

         writer.write(cols + " " + rows + " " + cellSize + "\n");

         // Write slope data
         for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
               writer.write(String.format("%.4f", slopeGrid[y][x]));
               if (x < cols - 1) {
                  writer.write(" ");
               }
            }
            writer.write("\n");
         }
      }
   }

   public void addPoint(Point point) {
      if (allPoints == null) {
         allPoints = new ArrayList < > ();
      }
      allPoints.add(point);
   }

   public List < Point > getPointsWithinRadius(Point center, double radius) {
      List < Point > pointsWithinRadius = new ArrayList < > ();

      if (allPoints == null) {
         return pointsWithinRadius;
      }

      for (Point point: allPoints) {
         if (calculateDistance(center, point) <= radius) {
            pointsWithinRadius.add(point);
         }
      }
      return pointsWithinRadius;
   }

   public double calculateDistance(Point p1, Point p2) {
      double dx = p1.getX() - p2.getX();
      double dy = p1.getY() - p2.getY();
      return Math.sqrt(dx * dx + dy * dy);
   }

   public double getActualWidth(){return actualWidth;}
   public double getActualHeight(){return actualHeight;}

   public double getWidth() {
      return cols * cellSize;
   }

   public int getCols() {
      return cols;
   }

   public int getRows() {
      return rows;
   }

   public List < Point > getPoints() {
      return allPoints;
   }

   public double getCellSize() {
      return cellSize;
   }
}