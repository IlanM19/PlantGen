import javax.swing.*;
import java.awt.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class EcosystemVisualizer extends JFrame {
    private final SpatialGrid spatialGrid;
    private final List<Point> plants;
    private final Random random;
     private final Map<String, Color> speciesColorMap;


    public EcosystemVisualizer(SpatialGrid spatialGrid, List<Point> plants, long seed) {
        this.spatialGrid = spatialGrid;
        this.plants = plants;
        this.random = new Random(seed);
        this.speciesColorMap = new HashMap<>();
        setTitle("Ecosystem Visualizer");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        TerrainPanel terrainPanel = new TerrainPanel();
        add(terrainPanel, BorderLayout.CENTER);
    }

    private static final Color[] DISTINCT_COLORS = {
    new Color(230, 25, 75),   // Red
    new Color(60, 180, 75),   // Green
    new Color(255, 225, 25),  // Yellow
    new Color(0, 130, 200),   // Blue
    new Color(245, 130, 48),  // Orange
    new Color(70, 240, 240),  // Cyan
    new Color(240, 50, 230),  // Magenta
    new Color(230, 190, 255), // Lavender
    new Color(170, 110, 40),  // Brown
    new Color(128, 0, 0),     // Maroon
    new Color(128, 128, 0),   // Olive
    new Color(0, 0, 128)      // Navy
};
    private int colorIndex = 0;
    
    private Color getColorForSpecies(Species species) {
    String speciesName = species.getCommonName();
    if (!speciesColorMap.containsKey(speciesName)) {
        Color newColor = DISTINCT_COLORS[colorIndex % DISTINCT_COLORS.length];
        speciesColorMap.put(speciesName, newColor);
        colorIndex++;
    }
    return speciesColorMap.get(speciesName);
}

    class TerrainPanel extends JPanel {
@Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;

    int width = spatialGrid.getCols();
    int height = spatialGrid.getRows();
    double actualWidth = spatialGrid.getActualWidth();
    double actualHeight = spatialGrid.getActualHeight();
    double scaleX = getWidth() / actualWidth;
    double scaleY = getHeight() / actualHeight;


    double minElevation = Double.MAX_VALUE;
    double maxElevation = Double.MIN_VALUE;

    // Find min and max elevation
    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            double elevation = spatialGrid.interpolateElevation(x * spatialGrid.getCellSize(), y * spatialGrid.getCellSize());
            minElevation = Math.min(minElevation, elevation);
            maxElevation = Math.max(maxElevation, elevation);
        }
    }

    // Draw terrain
    for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
            double elevation = spatialGrid.interpolateElevation(x * spatialGrid.getCellSize(), y * spatialGrid.getCellSize());
            int gray = (int) (255 * (elevation - minElevation) / (maxElevation - minElevation));
            gray = Math.max(0, Math.min(255, gray));
            g2d.setColor(new Color(gray, gray, gray));

            int pixelX = (int)(x * spatialGrid.getCellSize() * scaleX);
            int pixelY = (int)(y * spatialGrid.getCellSize() * scaleY);
            int pixelWidth = (int)(spatialGrid.getCellSize() * scaleX) + 1;
            int pixelHeight = (int)(spatialGrid.getCellSize() * scaleY) + 1;

            g2d.fillRect(pixelX, pixelY, pixelWidth, pixelHeight);

        }
    }

    // Draw plants
    for (Point plant : plants) {
        if (plant.getSpecies() != null) {
            Color color = getColorForSpecies(plant.getSpecies());
            g2d.setColor(color);
            int diameter = (int) (plant.getCanopyRadius() * 2 * Math.min(scaleX, scaleY));
            int x = (int) (plant.getX() * scaleX);
            int y = (int) (plant.getY() * scaleY);
            g2d.fillOval(x - diameter/2, y - diameter/2, diameter, diameter);
        }
    }

    // Draw legend
    drawLegend(g2d);

}

        private void drawLegend(Graphics2D g2d) {
            int legendX=10;
            int legendY=10;
            int swatchSize = 20;
            int textOffset = 5;

            for (Map.Entry<String, Color> entry : speciesColorMap.entrySet()) {
                g2d.setColor(entry.getValue());
                g2d.fillRect(legendX, legendY, swatchSize, swatchSize);
                g2d.setColor(Color.BLACK);
                g2d.drawString(entry.getKey(), legendX + swatchSize + textOffset, legendY + swatchSize);
                legendY += swatchSize + 5;
            }
        }

    }
}