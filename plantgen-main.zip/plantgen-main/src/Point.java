public class Point {
   public double x;
   public double y;
   public double elevation;
   public double slope;
   public double[] sunlight;
   public double[] temperature;
   public double[] moisture;
   public Species species;
   private int age;
   private double height;
   private double canopyRadius;
   private boolean isCanopy;

   public Point(double x, double y) { //, double elevation, double slope, double sunlight, double temperature, double moisture) {
      this.x = x;
      this.y = y;
      this.sunlight = new double[12];
      this.temperature = new double[12];
      this.moisture = new double[12];
   }

   public double getX() {
      return this.x;
   }
   public double getY() {
      return this.y;
   }
   public double getElevation() {
      return elevation;
   }
   public double getSlope() {
      return slope;
   }



   public Species getSpecies() {
      return species;
   }
   public int getAge() {
      return age;
   }
   public double getHeight() {
      return height;
   }
   public double getCanopyRadius() {
      return canopyRadius;
   }

   public void setAbioticData(double elevation, double slope, double[] sunlight, double[] temperature, double[] moisture) {
      this.elevation = elevation;
      this.slope = slope;
      this.sunlight = sunlight;
      this.temperature = temperature;
      this.moisture = moisture;
   }

   public void setSpecies(Species species) {
      this.species = species;
   }
   public void setAge(int age) {
      this.age = age;
   }
   public void setHeight(double height) {
      this.height = height;
   }
   public void setCanopyRadius(double canopyRadius) {
      this.canopyRadius = canopyRadius;
   }

   // Method to get a specific months data
   public double getSunlight(int month) {
      return sunlight[month];
   }
   public double getTemperature(int month) {
      return temperature[month];
   }
   public double getMoisture(int month) {
      return moisture[month];
   }

   public void setSunlight(int month, double newSunlight) {
      this.sunlight[month] = newSunlight;
   }

   public void setMoisture(int month, double newMoisture) {
      this.moisture[month] = newMoisture;
   }

   public void setCanopy(boolean isCanopy) {
      this.isCanopy = isCanopy;
   }

}