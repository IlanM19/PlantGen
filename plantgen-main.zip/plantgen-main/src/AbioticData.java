import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AbioticData {
   private Double[][][] monthlyData; // [month][row][col]
   private int dimX;
   private int dimY;
   private double gridSpacing;
   private final boolean hasGridSpacing; // Flag to check if gridSpacing is present

   // Constructor to initialize with a file path
   public AbioticData(String filePath, boolean hasGridSpacing) {
      this.hasGridSpacing = hasGridSpacing;
      loadAbioticData(filePath);
   }

   // Method to load the data from the file
   public void loadAbioticData(String filePath) {
      try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
         // Read header
         String header = reader.readLine();
         if (header == null) {
            System.err.println("Header line is missing or file is empty.");
            return;
         }

         String[] headerParts = header.split(" ");
         dimX = Integer.parseInt(headerParts[0]);
         dimY = Integer.parseInt(headerParts[1]);

         if (hasGridSpacing) {
            gridSpacing = Double.parseDouble(headerParts[2]);
         }

         // Read the data line
         String dataLine = reader.readLine();
         if (dataLine == null) {
            System.err.println("Data line is missing or file is empty.");
            return;
         }

         // Split the data line into values
         String[] values = dataLine.trim().split(" ");
         int totalValues = values.length;
         // Determine the number of months based on the total number of values
         int numMonths = totalValues / (dimX * dimY);
         if (totalValues % (dimX * dimY) != 0) {
            System.err.println("Data size does not evenly divide into the expected grid dimensions.");
            return;
         }

         // Initialize the data array for storing monthly values
         monthlyData = new Double[numMonths][dimY][dimX];

         // Fill monthlyData
         int index = 0;
         for (int month = 0; month < numMonths; month++) {
            for (int row = 0; row < dimY; row++) {
               for (int col = 0; col < dimX; col++) {
                  try {
                     monthlyData[month][row][col] = Double.parseDouble(values[index++]);
                  } catch (NumberFormatException e) {
                     System.err.println("Invalid number format: " + values[index - 1]);
                  }
               }
            }
         }

         System.out.println("Abiotic data loaded successfully!");

      } catch (IOException e) {
         System.err.println("Error reading Abiotic data: " + e.getMessage());
      }
   }

   // Method to print the abiotic data (for debugging and testing)
   public void printAbioticData() {
      for (int month = 0; month < monthlyData.length; month++) {
         System.out.println("Month " + (month + 1) + ":");
         for (int row = 0; row < dimY; row++) {
            for (int col = 0; col < dimX; col++) {
               System.out.print((monthlyData[month][row][col] != null ? monthlyData[month][row][col] : "null") + " ");
            }
            System.out.println();
         }
         System.out.println();
      }
   }

   public Double[][][] getMonthlyData() {
      return this.monthlyData;
   }

}