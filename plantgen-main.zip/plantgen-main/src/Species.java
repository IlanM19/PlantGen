 public class Species {
    private String name;
    private String commonName;
    private String scientificName;
    private String type;
    private String form;
    private int maxAge;
    private int lifespan;
    private double maxHeightOpen;
    private double maxHeightClosed;
    private double radiusMultiplierOpen;
    private double radiusMultiplierClosed;
    private double leafTransparency;
    private double moistureAbsorption;
    private double q;
    private AbioticParameters abioticParameters;

    // Constructor to initialize the species
    public Species(String commonName, String scientificName, String type, String form,
       int lifespan, double maxHeightOpen, double maxHeightClosed, int q,
       double radiusMultiplierOpen, double radiusMultiplierClosed,
       double leafTransparency, double moistureAbsorption,
       AbioticParameters abioticParameters) {
       this.commonName = commonName;
       this.scientificName = scientificName;
       this.type = type;
       this.form = form;
       this.lifespan = lifespan;
       this.maxHeightOpen = maxHeightOpen;
       this.maxHeightClosed = maxHeightClosed;
       this.q = q;
       this.radiusMultiplierOpen = radiusMultiplierOpen;
       this.radiusMultiplierClosed = radiusMultiplierClosed;
       this.leafTransparency = leafTransparency;
       this.moistureAbsorption = moistureAbsorption;
       this.abioticParameters = abioticParameters;
    }

    public double getRadiusMultiplierClosed() {
       return radiusMultiplierClosed;
    }

    public double getRadiusMultiplierOpen() {
       return radiusMultiplierOpen;
    }

    public int getLifespan() {
       return lifespan;
    }

    public String getCommonName() {
       return commonName;
    }

    public double getLeafTransparency() {
       return leafTransparency;
    }

    public double getMoistureAbsorption() {
       return moistureAbsorption;
    }



    public static class AbioticParameters {
       private double sunC;
       private double sunR;
       private double moistureC;
       private double moistureR;
       private double temperatureC;
       private double temperatureR;
       private double slopeC;
       private double slopeR;

       public AbioticParameters(double sunC, double sunR, double moistureC, double moistureR,
          double temperatureC, double temperatureR, double slopeC, double slopeR) {
          this.sunC = sunC;
          this.sunR = sunR;
          this.moistureC = moistureC;
          this.moistureR = moistureR;
          this.temperatureC = temperatureC;
          this.temperatureR = temperatureR;
          this.slopeC = slopeC;
          this.slopeR = slopeR;
       }
       //get methods
       public double getSunC()

       {
          return sunC;
       }

       public double getSunR()

       {
          return sunR;
       }

       public double getMoistureC()

       {
          return moistureC;
       }

       public double getMoistureR()

       {
          return moistureR;
       }

       public double getTemperatureC()

       {
          return temperatureC;
       }

       public double getTemperatureR()

       {
          return temperatureR;
       }

       public double getSlopeC()

       {
          return slopeC;
       }
       public double getSlopeR()

       {
          return slopeR;
       }

    }
    // Viability calculation
    public double calculateViability(double temperature, double moisture, double sunlight, double slope) {

       double a = 0.2; // Maximum stress value

       // Abiotic distances (rs) and ideal conditions (cs) specific to this species
       AbioticParameters params = this.abioticParameters;
       double temperatureViability = calculateAdaptation(temperature, params.getTemperatureC(), params.getTemperatureR(), a);
       double moistureViability = calculateAdaptation(moisture, params.getMoistureC(), params.getMoistureR(), a);
       double sunlightViability = calculateAdaptation(sunlight, params.getSunC(), params.getSunR(), a);
       double slopeViability = calculateAdaptation(slope, params.getSlopeC(), params.getSlopeR(), a);

       // Calculate viability as the minimum of the adaptation functions
       return Math.min(Math.min(temperatureViability, moistureViability), Math.min(sunlightViability, slopeViability));

    }

    // Adaptation function
    private double calculateAdaptation(double value, double cs, double rs, double a) {
       double d = Math.abs(value - cs);
       return (1 + a) * Math.exp(Math.pow(d / rs, 4.5) * Math.log(0.2)) - a;
    }

    // Method to calculate growth of species
    public double calculateGrowth(double time, boolean isClosed) {
       double h = isClosed ? maxHeightClosed : maxHeightOpen;
       return (2 / (1 + Math.exp((time / lifespan) * q)) - 1) * h;
    }
 }