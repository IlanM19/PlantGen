import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class EcosystemGenerator extends JFrame implements ActionListener {


   private final List < Species > speciesList;
   private int canopyPlantsPlaced = 0;
   private int understoryPlantsPlaced = 0;

   JTextField t1, t2, t3, t4, t5, t6;
   JButton b1, browseButton;
   JTextField tViabilityThreshold;


   public EcosystemGenerator(List < Species > speciesList) {
      super("PlantGen Ecosystem Generator");
      this.speciesList = speciesList;
      initializeGUI();
   }

   private void initializeGUI() {
       setTitle("PlantGen: Ecosystem Generator");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(500, 450);
    setLocationRelativeTo(null);  // Center the window

    JPanel mainPanel = new JPanel(new GridBagLayout());
    mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
    setContentPane(mainPanel);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(5, 5, 5, 5);

    // Samples Panel
    JPanel samplesPanel = createPanel("Samples");
    addLabelAndField(samplesPanel, "Canopy:", t1 = new JTextField(10));
    addLabelAndField(samplesPanel, "Understory:", t2 = new JTextField(10));
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    mainPanel.add(samplesPanel, gbc);

    // Spacing Panel
    JPanel spacingPanel = createPanel("Minimum Point Spacing");
    addLabelAndField(spacingPanel, "Canopy:", t3 = new JTextField(10));
    addLabelAndField(spacingPanel, "Understory:", t4 = new JTextField(10));
    gbc.gridy = 1;
    mainPanel.add(spacingPanel, gbc);

    // Seed and Threshold Panel
    JPanel seedThresholdPanel = createPanel("Seed and Threshold");
    addLabelAndField(seedThresholdPanel, "Random Seed:", t5 = new JTextField(10));
    addLabelAndField(seedThresholdPanel, "Viability Threshold:", tViabilityThreshold = new JTextField(10));
    gbc.gridy = 2;
    mainPanel.add(seedThresholdPanel, gbc);

    // Directory Panel
    JPanel dirPanel = createPanel("Base Directory");
    t6 = new JTextField(20);
    t6.setEditable(false);
    dirPanel.add(t6);
    browseButton = new JButton("Browse");
    browseButton.addActionListener(e -> browseDirectory());
    dirPanel.add(browseButton);
    gbc.gridy = 3;
    mainPanel.add(dirPanel, gbc);

    // Generate Button
    b1 = new JButton("Generate Ecosystem");
    b1.setBackground(new Color(0, 123, 255));
    b1.setForeground(Color.WHITE);
    b1.setFocusPainted(false);
    b1.addActionListener(this);
    gbc.gridy = 4;
    gbc.gridwidth = 2;
    gbc.insets = new Insets(20, 5, 5, 5);
    mainPanel.add(b1, gbc);

    setVisible(true);
   }
   private JPanel createPanel(String title) {
    JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
    panel.setBorder(BorderFactory.createTitledBorder(title));
    return panel;
}
private void addLabelAndField(JPanel panel, String labelText, JTextField field) {
    panel.add(new JLabel(labelText));
    panel.add(field);
}
private void browseDirectory() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    int option = fileChooser.showOpenDialog(this);
    if (option == JFileChooser.APPROVE_OPTION) {
        File file = fileChooser.getSelectedFile();
        t6.setText(file.getAbsolutePath());
    }
}
   public static void main(String[] args) {
      List < Species > speciesList = createSpeciesList();

      SwingUtilities.invokeLater(() -> new EcosystemGenerator(speciesList));

   }

   private static List < Species > createSpeciesList() {
      List < Species > speciesList = new ArrayList < > ();

      Species Boxwood = new Species(
         "Boxwood",
         "Buxus sempervirens",
         "Broad-leaved Evergreen",
         "Shrub/Tree",
         300,
         9,
         9,
         -5,
         0.42,
         0.42,
         0.70,
         15,
         new Species.AbioticParameters(
            3.75, 4.25,
            27.5, 12.5,
            11.75, 23.35,
            0, 80
         )
      );

      Species SnowyMespilus = new Species(
         "Snowy Mespilus",
         "Amelanchier ovalis",
         "Deciduous",
         "Shrub",
         50,
         6,
         6,
         -4,
         0.41,
         0.17,
         0.52,
         22,
         new Species.AbioticParameters(
            7, 5,
            31, 9,
            19.25, 15.75,
            0, 80
         )
      );

      Species MountainPine = new Species(
         "Mountain Pine",
         "Pinus uncinata",
         "Evergreen, treeline species",
         "Tree",
         400,
         15,
         20,
         -4,
         0.16,
         0.14,
         0.43,
         3,
         new Species.AbioticParameters(
            7, 5,
            21.5, 18.5,
            11.75, 23.25,
            0, 80
         )
      );

      Species SilverFir = new Species(
         "Silver Fir",
         "Abies alba",
         "Conifer",
         "Tree",
         550,
         40,
         50,
         -6,
         0.12,
         0.07,
         0.47,
         22,
         new Species.AbioticParameters(
            5, 3,
            31, 9,
            11.75, 23.25,
            0, 80
         )
      );

      Species SilverBirch = new Species(
         "Silver Birch",
         "Betula pendula",
         "Deciduous",
         "Tree",
         120, // lifespan
         18, // maxHeightOpen
         25, // maxHeightClosed
         -4, // q
         0.20, // radiusMultiplierOpen
         0.10, // radiusMultiplierClosed
         0.30, // leafTransparency
         15, // moistureAbsorption
         new Species.AbioticParameters(
            8.25, 3.75, // sunC, sunR
            27.5, 12.5, // moistureC, moistureR
            19.25, 15.75, // temperatureC, temperatureR
            0, 70 // slopeC, slopeR
         )
      );

      Species SessileOak = new Species(
         "Sessile Oak",
         "Quercus petraea",
         "Deciduous",
         "Tree",
         600, // lifespan
         30, // maxHeightOpen
         45, // maxHeightClosed
         -7, // q
         0.38, // radiusMultiplierOpen
         0.21, // radiusMultiplierClosed
         0.35, // leafTransparency
         15, // moistureAbsorption
         new Species.AbioticParameters(
            5, 3, // sunC, sunR
            37.5, 22.5, // moistureC, moistureR
            19.25, 15.75, // temperatureC, temperatureR
            0, 70 // slopeC, slopeR
         )
      );

      Species EuropeanBeech = new Species(
         "European Beech",
         "Fagus sylvatica",
         "Deciduous",
         "Tree",
         400, // lifespan
         35, // maxHeightOpen
         50, // maxHeightClosed
         -4, // q
         0.30, // radiusMultiplierOpen
         0.13, // radiusMultiplierClosed
         0.37, // leafTransparency
         15, // moistureAbsorption
         new Species.AbioticParameters(
            5.75, 6.25, // sunC, sunR
            37.5, 22.5, // moistureC, moistureR
            19.25, 15.75, // temperatureC, temperatureR
            0, 70 // slopeC, slopeR
         )
      );
      speciesList.add(Boxwood);
      speciesList.add(SnowyMespilus);
      speciesList.add(MountainPine);
      speciesList.add(SilverFir);
      speciesList.add(SilverBirch);
      speciesList.add(SessileOak);
      speciesList.add(EuropeanBeech);
      // Add species to the list

      return speciesList;
   }

   public void generateEcosystem() {
      int canopySamples = Integer.parseInt(t1.getText());
      int understorySamples = Integer.parseInt(t2.getText());
      double minPointSpacingCanopy = Double.parseDouble(t3.getText());
      double minPointSpacingUnderstory = Double.parseDouble(t4.getText());
      long randomSeed = Long.parseLong(t5.getText());
      double viabilityThreshold = Double.parseDouble(tViabilityThreshold.getText());


      String dataPath = t6.getText();

      String[] parts = dataPath.split("\\\\");
      String folderName = parts[parts.length - 1];

      //File Loading

      ElevationData elv_data = new ElevationData(dataPath + File.separator + folderName + ".elv");
      AbioticData sun_data = new AbioticData(dataPath + File.separator + folderName + "_sun.txt", true);
      AbioticData temp_data = new AbioticData(dataPath + File.separator + folderName + "_temp.txt", false);
      AbioticData wet_data = new AbioticData(dataPath + File.separator + folderName + "_wet.txt", false);
      Double[][] elevationArray = elv_data.getElevationData(); // You might need to add this method to your ElevationData class
      double actualWidth = elv_data.getDimX() * elv_data.getGridSpacing();
      double actualHeight = elv_data.getDimY() * elv_data.getGridSpacing();

      SpatialGrid spatialGrid = new SpatialGrid(elv_data.getDimX(), elv_data.getDimY(),
         elv_data.getGridSpacing(), elevationArray, sun_data, wet_data, temp_data,actualWidth, actualHeight);
      try {
         spatialGrid.exportSlopeData(dataPath + File.separator + folderName + "_slope.txt");
      } catch (IOException e) {
         throw new RuntimeException(e);
      }

      PinkNoiseGenerator noiseGenerator = new PinkNoiseGenerator(actualWidth, actualHeight, minPointSpacingCanopy, elv_data.getGridSpacing(), canopySamples, understorySamples, randomSeed);

      //Timing benchmarking
      double startTime = System.nanoTime();


      // Generate samples
      //Canopy Layer
      System.out.println("Canopy samples complete.");
      List < Point > canopyPoints = noiseGenerator.generatePinkNoiseSamples(canopySamples);
      populateAbioticData(canopyPoints, spatialGrid);
      for (Point point: canopyPoints) {
         point.setCanopy(true);
         spatialGrid.addPoint(point);
      }

      //Understory Layer
      System.out.println("Understory samples complete.");
      noiseGenerator.setMinDistance(minPointSpacingUnderstory);
      List < Point > understoryPoints = noiseGenerator.generatePinkNoiseSamples(understorySamples);
      populateAbioticData(understoryPoints, spatialGrid);
      for (Point point: understoryPoints) {
         point.setCanopy(false);
         spatialGrid.addPoint(point);
      }

      ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
      CountDownLatch latch = new CountDownLatch(understoryPoints.size()+canopyPoints.size());

      processPointsInParallel(canopyPoints, executor, latch, true, spatialGrid,viabilityThreshold);
      processPointsInParallel(understoryPoints, executor, latch, false, spatialGrid,viabilityThreshold);

      try{
         latch.await();

      } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
      }

      executor.shutdown();

      //End timing here
      double endTime = System.nanoTime();
      double duration = (endTime - startTime) / 1e9; // Convert to seconds
      System.out.println("Ecosystem generation took " + duration + " seconds");

      System.out.println("\nEcosystem generation completed!");
      printPlacementResults(getAllPlants(spatialGrid));

       //Send point data to respective unity build data folder.
       try {
           Path inputPath = Paths.get(dataPath);
           Path dataFolder = inputPath.getFileName();

           Path buildsPath = findBuildsFolderPath();
           Path outputBasePath = buildsPath.resolve("PlantGeneration_Data");
           Path specificOutputFolder = outputBasePath.resolve(dataFolder.toString().substring(0, 2));

           Files.createDirectories(specificOutputFolder);

           Path outputFilePath = specificOutputFolder.resolve(dataFolder + "_points.txt");

           outputPointDataToFile(getAllPlants(spatialGrid), outputFilePath.toString());


       } catch (IOException e) {
           System.err.println("Error creating output directory or file: " + e.getMessage());
           e.printStackTrace();

       }


       outputPointDataToFile(getAllPlants(spatialGrid), dataPath + File.separator + folderName +"_points.txt");
      // TODO: Add visualization or further processing of the generated ecosystem

      SwingUtilities.invokeLater(() -> {
         EcosystemVisualizer visualizer = new EcosystemVisualizer(spatialGrid, getAllPlants(spatialGrid), randomSeed);
         visualizer.setVisible(true);
      });

   }

   private List < Point > getAllPlants(SpatialGrid grid) {

      return grid.getPoints();
   }

   private void printPlacementResults(List<Point> points) {
      System.out.println("\n--- Plant Placement Results ---");
      System.out.println("Canopy plants placed: " + canopyPlantsPlaced);
      System.out.println("Understory plants placed: " + understoryPlantsPlaced);
      System.out.println("Total plants placed: " + (canopyPlantsPlaced + understoryPlantsPlaced));

      System.out.println("\nPlants placed by species:");
      Map<String, Integer> speciesCount = new HashMap<>();

      //For each occurrence of each species.
      for (Point plant : points) {
        if (plant.getSpecies() != null) {
            String speciesName = plant.getSpecies().getCommonName();
            speciesCount.put(speciesName, speciesCount.getOrDefault(speciesName, 0) + 1);
        }
     }

      // Print the count and percentage for each species
      int totalPlants = canopyPlantsPlaced + understoryPlantsPlaced;
      for (Map.Entry<String, Integer> entry : speciesCount.entrySet()) {
        String speciesName = entry.getKey();
        int count = entry.getValue();
        double percentage = (count * 100.0) / totalPlants;
        System.out.printf("%s: %d (%.2f%%)\n", speciesName, count, percentage);
      }

      // Print count of unassigned points
      int unassignedPoints = points.size() - totalPlants;
      double unassignedPercentage = (unassignedPoints * 100.0) / points.size();
      System.out.printf("Unassigned points: %d (%.2f%%)\n", unassignedPoints, unassignedPercentage);




   }

   public void outputPointDataToFile(List<Point> points, String fileName) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
        writer.write("Number of points: " + points.size());
        writer.newLine();
        writer.write("x y elevation slope age height canopyRadius species");
        writer.newLine();

        for (Point point : points) {
            StringBuilder line = new StringBuilder();
            line.append(String.format("%.4f %.4f %.4f %.4f ",
                point.getX(), point.getY(),
                point.getElevation(), point.getSlope()));

            if (point.getSpecies() != null) {
                line.append(String.format("%d %.4f %.4f %s",
                    point.getAge(),
                    point.getHeight(),
                    point.getCanopyRadius(),
                    point.getSpecies().getCommonName()));
            } else {
                line.append("0 0.0000 0.0000 None");
            }

            writer.write(line.toString());
            writer.newLine();
        }

        System.out.println("Point data has been written to " + fileName);
    } catch (IOException e) {
        System.err.println("Error writing to file: " + e.getMessage());
    }
}

private Path findBuildsFolderPath() throws IOException {
    Path currentPath = Paths.get(System.getProperty("user.dir"));
    while (currentPath != null) {
        Path buildsPath = currentPath.resolve("Builds");
        if (Files.exists(buildsPath) && Files.isDirectory(buildsPath)) {
            return buildsPath;
        }
        currentPath = currentPath.getParent();
    }
    throw new IOException("Builds folder not found in any parent directory");
}

    private void populateAbioticData(List < Point > points, SpatialGrid grid) {
      for (Point point: points) {
         double x = point.getX();
         double y = point.getY();
         double elevation = grid.interpolateElevation(x, y);
         double slope = grid.interpolateSlope(x, y);
         double[] sunlight = new double[12];
         double[] temperature = new double[12];
         double[] moisture = new double[12];

         for (int month = 0; month < 12; month++) {
            sunlight[month] = grid.interpolateSunlight(x, y, month);
            temperature[month] = grid.interpolateTemperature(x, y, month);
            moisture[month] = grid.interpolateMoisture(x, y, month);
         }

         point.setAbioticData(elevation, slope, sunlight, temperature, moisture);

      }

   }

   private Species selectSpecies(Point point) {
      double totalViability = 0;
      List < Species > viableSpecies = new ArrayList < > ();
      List < Double > viabilities = new ArrayList < > ();

      for (Species species: speciesList) {
         double averageViability = calculateAverageViability(point, species);
         if (averageViability > 0) {
            viableSpecies.add(species);
            viabilities.add(averageViability);
            totalViability += averageViability;
         }
      }

      if (totalViability <= 0) {
         return null; // No viable species for this point
      }

      double random = Math.random() * totalViability;
      double sum = 0;
      for (int i = 0; i < viableSpecies.size(); i++) {
         sum += viabilities.get(i);
         if (sum > random) {
            return viableSpecies.get(i);
         }
      }
      return null; // just in case
   }

   private double calculateAverageViability(Point point, Species species) {
      double totalViability = 0;
      for (int month = 0; month < 12; month++) {
         totalViability += species.calculateViability(
            point.getTemperature(month),
            point.getMoisture(month),
            point.getSunlight(month),
            point.getSlope()
         );
      }
      return totalViability / 12;
   }

   private void placePlant(Point point, Species species, SpatialGrid grid, boolean isCanopy, double viabilityThreshold) {
      // Calculate vigor (average viability)
      double vigor = calculateAverageViability(point, species);

      // Skip placement if vigor is not positive or below threshold
      if (vigor <= viabilityThreshold) {
         //System.out.println("Skipping plant placement due to non-positive vigor: " + vigor);
         return;
      }

      // Determine age range based on whether its canopy or understory
      int lifespan = species.getLifespan();
      double minAge, maxAge;
      if (isCanopy) {
         minAge = lifespan * 0.5;
         maxAge = lifespan;
         canopyPlantsPlaced++;

      } else {
         minAge = lifespan * 0.2;
         maxAge = lifespan * 0.5;
         understoryPlantsPlaced++;
      }

      // Randomly determine an age within the range
      double randomAge = minAge + Math.random() * (maxAge - minAge);

      // Determine vigor-adjusted age
      double adjustedAge = randomAge * vigor;

      // Determine if the area is closed or open
      boolean isClosed = determineIfClosed(point, grid);

      // Calculate height using the logistic growth function
      double height = species.calculateGrowth(adjustedAge, isClosed);

      // Calculate canopy radius
      double canopyRadius;
      if (isClosed) {
         canopyRadius = height * species.getRadiusMultiplierClosed();
      } else {
         canopyRadius = height * species.getRadiusMultiplierOpen();
      }

      // Adjust abiotic factors
      adjustAbioticFactors(point, canopyRadius, species, grid);

      // Set plant attributes
      point.setSpecies(species);
      point.setAge((int) adjustedAge);
      point.setHeight(height);
      point.setCanopyRadius(canopyRadius);

   }

   private boolean determineIfClosed(Point point, SpatialGrid grid) {
      double gridWidth = grid.getWidth();
      double checkRadius = gridWidth * 0.02;
      int plantCount = 0;
      List < Point > nearbyPoints = grid.getPointsWithinRadius(point, checkRadius);

      for (Point nearbyPoint: nearbyPoints) {
         if (nearbyPoint.getSpecies() != null) {
            plantCount++;
         }
      }

      // Consider it closed if more than 30% of nearby points have plants
      return (double) plantCount / nearbyPoints.size() > 0.3;
   }

   private void adjustAbioticFactors(Point center, double radius, Species species, SpatialGrid grid) {
      List < Point > affectedPoints = grid.getPointsWithinRadius(center, radius * 1.5);
      double leafTransparency = species.getLeafTransparency();
      double moistureAbsorption = species.getMoistureAbsorption();

      for (Point affectedPoint: affectedPoints) {
         double distance = grid.calculateDistance(center, affectedPoint);
         double factor = 1 - (distance / (radius * 1.5));

         for (int month = 0; month < 12; month++) {
            // Adjust sunlight
            double currentSunlight = affectedPoint.getSunlight(month);
            double newSunlight = currentSunlight * (leafTransparency + (1 - leafTransparency) * (1 - factor));
            affectedPoint.setSunlight(month, newSunlight);

            // Adjust moisture
            double currentMoisture = affectedPoint.getMoisture(month);
            double moistureReduction = moistureAbsorption * factor;
            double newMoisture = Math.max(0, currentMoisture - moistureReduction);
            affectedPoint.setMoisture(month, newMoisture);
         }
      }
   }

   private void processPointsInParallel(List<Point> points, ExecutorService executor, CountDownLatch latch, boolean isCanopy, SpatialGrid grid, double threshold) {
        for (Point point : points) {
            executor.submit(() -> {
                try {
                    Species selectedSpecies = selectSpecies(point);
                    if (selectedSpecies != null) {
                        placePlant(point, selectedSpecies, grid, isCanopy,threshold);
                    }
                } finally {
                    latch.countDown();
                }
            });
        }
    }

   @Override
   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == b1) {

         generateEcosystem();

      }
   }

}