import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ElevationData {
   private Double[][] elevationValues;
    private int dimX;
   private int dimY;
   private Double gridSpacing;

   public ElevationData(String filePath) {
      loadElevationData(filePath);
   }

   public int getDimX() {
      return this.dimX;
   }

   public int getDimY() {
      return this.dimY;
   }

   public Double getGridSpacing() {
      return this.gridSpacing;
   }

   private void loadElevationData(String filePath) {
      try (BufferedReader bufferReader = new BufferedReader(new FileReader(filePath))) {
         String header = bufferReader.readLine();
         String[] headerParts = header.split(" ");

         dimX = Integer.parseInt(headerParts[0]);
         dimY = Integer.parseInt(headerParts[1]);
         gridSpacing = Double.parseDouble(headerParts[2]);
         //Double latitude = Double.parseDouble(headerParts[3]);

         elevationValues = new Double[dimY][dimX];

         String line;
         int irow = 0;
         int icol = 0;

         while ((line = bufferReader.readLine()) != null) {
            line = line.trim(); // Remove leading and trailing whitespace


            if (line.isEmpty()) {
               continue; // Skip empty lines
            }

            String[] values = line.split(" ");

            for (String value: values) {
               if (!value.isEmpty()) { // Check if the string is not empty
                  try {
                     elevationValues[irow][icol] = Double.parseDouble(value);
                  } catch (NumberFormatException e) {
                     System.err.println("Error parsing value at row " + irow + ", col " + icol + ": " + value);
                  }
                  icol++;

                  if (icol == dimX) {
                     icol = 0;
                     irow++;
                  }
               }
            }
         }

         System.out.println("Elevation data loaded successfully!");

      } catch (IOException e) {
         System.err.println("Error reading Elevation data" + e.getMessage());
      }

   }


   public Double[][] getElevationData() {
      return elevationValues;
   }



}