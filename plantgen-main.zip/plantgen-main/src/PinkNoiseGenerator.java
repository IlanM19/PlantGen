import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.ConcurrentLinkedQueue;

public class PinkNoiseGenerator {

   private double width;
   private double height;
   private double minDistance;
   private double gridSpacing;
   private int canopyNumSamples;
   private int underNumSamples;
   private double size;

   private final Random random;

   private static final int THRESHOLD = 1000;

   public PinkNoiseGenerator(double actualWidth, double actualHeight, double minDistance, double gridSpacing, int canopyNumSamples, int underNumSamples, long seed) {
      this.width = actualWidth;
      this.height = actualHeight;
      this.minDistance = minDistance;
      this.canopyNumSamples = canopyNumSamples;
      this.underNumSamples = underNumSamples;
      this.gridSpacing = gridSpacing;
      this.size = width * gridSpacing;
      this.random = new Random(seed);

   }

   public List<Point> generatePinkNoiseSamples(int samples) {
      ForkJoinPool pool = ForkJoinPool.commonPool();
      ConcurrentLinkedQueue<Point> sampleQueue = new ConcurrentLinkedQueue<>();
      pool.invoke(new PinkNoiseTask(samples, sampleQueue));
      return new ArrayList<>(sampleQueue);

   }

   public void setMinDistance(double minDistance) {
         this.minDistance = minDistance;
   }

   private class PinkNoiseTask extends RecursiveTask<Void> {
      private int samples;
      private ConcurrentLinkedQueue<Point> sampleQueue;

      PinkNoiseTask(int samples, ConcurrentLinkedQueue<Point> sampleQueue) {
         this.samples = samples;
         this.sampleQueue = sampleQueue;
      }

      @Override
      protected Void compute() {
         if (samples <= THRESHOLD) {
            for (int i = 0; i < samples; i++) {
               Point newPoint = generateRandomSample();
               if (isValidPoint(newPoint, new ArrayList<>(sampleQueue))) {
                  sampleQueue.offer(newPoint);
               }
            }
         } else {
            int split = samples / 2;
            PinkNoiseTask left = new PinkNoiseTask(split, sampleQueue);
            PinkNoiseTask right = new PinkNoiseTask(samples - split, sampleQueue);
            left.fork();
            right.compute();
            left.join();
         }
         return null;
      }


      private Point generateRandomSample() {
         double x = random.nextDouble() * width;
         double y = random.nextDouble() * height;
         return new Point(x, y);
      }

      public boolean isValidPoint(Point newPoint, Collection<Point> existingPoints) {
         for (Point existingPoint : existingPoints) {
            double distance = calculateDistance(newPoint, existingPoint);
            if (distance < minDistance) {
               return false;
            }
         }
         return true;
      }

      private double calculateDistance(Point p1, Point p2) {
         double dx = p1.getX() - p2.getX();
         double dy = p1.getY() - p2.getY();
         return Math.sqrt(dx * dx + dy * dy);
      }


   }
}