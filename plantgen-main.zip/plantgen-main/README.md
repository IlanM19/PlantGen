# PlantGen: Ecosystem Generation Software

## Description
PlantGen is an ecosystem generation software designed to simulate plant distribution and growth based on various environmental factors. It generates realistic plant placements for different terrain types and outputs data compatible with Unity for visualization.
gitlab link: https://gitlab.cs.uct.ac.za/plantgen-gij/plantgen

## Authors
- Gideon Sweijd - SWJGID001
- Jayden Moore  - MRXJAY001
- Ilan Moyal    - MYLILA001

## Table of Contents
1. [Installation](#installation)
2. [Usage](#usage)
3. [File Structure](#file-structure)
4. [Input Data](#input-data)
5. [Output Data](#output-data)
6. [Troubleshooting](#troubleshooting)

## Installation
1. Ensure you have Java JDK 11 or later installed on your system.
2. Clone this repository or download the source code alongside the unity build folder.
3. Ensure you have the corrrect data folders,  with data in the correct format as outlined by the client.
3. Open the project in your preferred Java IDE (e.g., IntelliJ IDEA, Eclipse).

## Usage
1. Run the `EcosystemGenerator` class to start the application.
2. In the GUI:
   - Enter the number of canopy and understory samples.
   - - Enter sample sizes proportional to the size of the terrain.
   - Set the minimum point spacing for canopy and understory. 
   - Enter a random seed for reproducibility.
   - Set the viability threshold, this number should be between 0 and 1.
   -  - The optimal threshold found is between [0.15;0.2]
   - Select the input data folder using the "Browse" button.
   - - Select either D1/D2/D3/D4, do not enter into these folders.
3. Click "Generate Ecosystem" to run the simulation.
4. The output will be saved in the `Builds/PlantGeneration_Data` directory.
5. Once you have generated data from java, navigate to the  `Builds` folder and run the **PlantGeneration.exe** executable to render output in unity.
6. In the unity GUI:
   - Select the terrain that you just generated plants for (D1/D2/D3/D4).
   - Read the movement controls.
   - Click Generate Ecosystem button.
   - Explore the terrain.

## File Structure
~~~
plantgen/
├── src/
│   └── (Java source files)
├──unity_src/
│   └── (Unity C# source files)
├── Data/
│   ├── D1-256/
│   ├── D2-512/
│   ├── D3-1024/
│   └── D4-1024/
├── Builds/
    └── PlantGeneration.exe
│   └── PlantGeneration_Data/
│       ├── D1/
│       ├── D2/
│       ├── D3/
│       └── D4/
├──gallery/
│   └──species/ (unity species pictures)
│   └──showcase/ (screenshots of render)
└── README.md
~~~

## Input Data
The software requires specific input data files:
- Elevation data (.elv files)
- Sun exposure data (_sun.txt files)
- Temperature data (_temp.txt files)
- Moisture data (_wet.txt files)

Ensure these files are present in the corresponding data folders (D1-256, D2-512, etc.).

## Output Data
The software generates point data files in the `Builds/PlantGeneration_Data/D(1/2/3/4)` directory. These files contain information about plant placements and can be used for visualization in Unity. 
The software also generates slope data, this is found in the Data folder you initally selected.

**If, on the off chance, that point data is not being found in this directory, they are also outputted back to the data folder you selected, and can be manually moved to their respective correct folder if needed.**

## Troubleshooting
- If you encounter "File not found" errors, ensure all input data files are in the correct locations.
- For "Out of memory" errors, try increasing the Java heap size.
- If the GUI doesn't appear, check your Java installation and IDE configuration.
